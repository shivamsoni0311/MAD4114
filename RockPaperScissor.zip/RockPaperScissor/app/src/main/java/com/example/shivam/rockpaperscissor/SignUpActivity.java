package com.example.shivam.rockpaperscissor;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;


import java.util.Arrays;

public class SignUpActivity extends AppCompatActivity implements View.OnClickListener {

    Button btnSMS;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        btnSMS = findViewById(R.id.btnSMS);
        btnSMS.setOnClickListener(this);





    }


    @Override
    public void onClick(View v) {

        Intent i = new Intent(this,LoginActivity.class);
        startActivity(i);




    }

   /* private void sendSMS(){
        Intent smsIntent = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:1234567890"));
        smsIntent.putExtra("sms_body", "This is test message");

        if (ActivityCompat.checkSelfPermission(getApplicationContext(),
                Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED){
            Toast.makeText(getApplicationContext(),
                    "SMS Permission Denied", Toast.LENGTH_SHORT).show();
            return;
        }

        startActivity(smsIntent);

    }  */


}
